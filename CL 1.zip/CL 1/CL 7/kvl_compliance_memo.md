TO: Board of Directors, KVL Camps; Bureau of Youth Camp Licensing
FROM: Operations Director
DATE: July 14, 2026
SUBJECT: Swim Assessment Credential Audit & CAP Baseline

This memo summarizes the swim assessment credential record, waterfront operational logs, and related enrollment exposure for KVL Camps, focusing primarily on the Corrigwell site following the June 15, 2026 finding (Bureau Case No. BYC-FND-2026-0147). This research is based solely on program records available through July 14, 2026.

### Step 1: Credential Record Establishment
A review of the *Corrigwell Swim Classification Rosters* (2022–2026) and the *Corrigwell Lifeguard Certification Files* (2022–2026) establishes the following credential record for the Corrigwell site:
*   **Signer of Record (2022 through July 14, 2026)**: Martin T. Eberly, Aquatics Supervisor.
*   **Credential Held**: AQS - Aquatics Supervisor Certificate (Aldervale Recreation and Parks Association). 
*   **Credential-Track Authorization Matrix**: The *Credential-Track Authorization Matrix* clearly states "Swim-Ability Assessment Authority: No" for the AQS credential. While it permits Deep-Water Supervision, it does not authorize the holder to sign off on swim-ability assessments.

**Origin of the Assignment**: According to the *Spring 2022 Aquatics Hiring Memo* and the *Aquatics Leadership Meeting Minutes 2022-2026*, the assignment began following the departure of the former Waterfront Director, Sandra Ohman, after the 2021 season. Martin T. Eberly was hired to replace her as Aquatics Supervisor in Spring 2022, with his duties explicitly defined to include "supervision of the swim-testing table including roster sign-off." The hire was processed through the standard seasonal pipeline as a routine seasonal hire. The meeting minutes from December 8, 2025, note that the authorization matrix was not consulted during this 2022 hiring process.

**Appearance of the Gap**: The gap between the credential held and the credential required (LG-WF, WSI, or LGI) first appears in the program records during the spring 2022 hire, manifested specifically on the *Corrigwell Swim Classification Roster 2022*, which Martin T. Eberly signed.

### Step 2: Operational Record Assessment
Using the credential period established (2022–2026), an assessment of the *Corrigwell Water Quality Logs* and *Corrigwell Ratio Schedules* was conducted. Logs for 2022, 2023, and 2024 were not found in the provided files; therefore, the analysis relies on the 2025 and 2026 logs.
Per the *Waterfront Standard Operating Policies*, Corrigwell is an outdoor site maintaining Cyanuric Acid levels between 30-50 ppm. When Cyanuric Acid is utilized, the required Free Chlorine range is 2.0-4.0 ppm.

*   **2025 Season**: 
    *   Out-of-range entries: 71 entries fell outside the target range (all 71 were Free Chlorine readings below 2.0 ppm). pH, Combined Chlorine, and Cyanuric Acid had 0 excursions.
    *   Corrective actions: 16 corrective actions were logged; 55 out-of-range entries had no action logged.
    *   Ratio Schedule: 0 excursions (the 1:25 standard was met continuously).
*   **2026 Season (through July 14, 2026)**:
    *   Out-of-range entries: 37 entries fell outside the target range (all 37 were Free Chlorine readings below 2.0 ppm). pH, Combined Chlorine, and Cyanuric Acid had 0 excursions.
    *   Corrective actions: 9 corrective actions were logged; 28 out-of-range entries had no action logged.
    *   Ratio Schedule: 0 excursions.

**Discrepancy Note**: Several summary documents, such as the *Scope Isolation Memo 2026*, characterize the operational record as "clean", and the *Mid-Season Operations Update July 2026* reports only two instances of high free chlorine. However, verifying against the underlying logs using the exact parameters in the *Waterfront Standard Operating Policies* reveals 71 excursions in 2025 and 37 in 2026. The underlying logs are more reliable as they contain the raw, uninterpreted data; therefore, the summary documents' characterization must not be adopted.

### Step 3: Application to Sites Not Yet Reviewed
Using the credential gap identified in Step 1 as a reference, the current swim-classification rosters for four additional sites were sought out.

*   **Bluegill Point**: The *Bluegill Point 2026 Swim Classification Roster* was pulled and reviewed. The signer is Alicia Mora, Waterfront Director, holding an LG-WF (Waterfront Skills Lifeguarding) credential. The matrix authorizes LG-WF for assessments; thus, the authorization gap does not exist here.
*   **Otter Run**: The *Otter Run 2026 Swim Classification Roster* was pulled and reviewed. The signer is Kim Ostrander, Waterfront Director, holding a WSI (Water Safety Instructor) credential. The matrix authorizes WSI; the authorization gap does not exist here.
*   **Tamarack Ridge and Heron Landing**: Rosters and certification files for these two sites were not pulled and reviewed as of July 14, 2026. 
    *   **Status Meaning**: Because their records were not reviewed, their status is neither cleared nor found defective. This status represents an absence of examination and a critical gap in organizational knowledge. 
    *   **Records Needed**: To resolve this, the *Swim Classification Rosters* (specifically the signature blocks) and the corresponding *Lifeguard Certification Files* for both sites must be reviewed and compared against the *Credential-Track Authorization Matrix*.
    *   **Risk**: If this gap is left unaddressed, unauthorized staff may currently be certifying camper assessments at these sites. This could result in campers being placed in water depths exceeding their ability, presenting a severe risk to life safety and a direct violation of state regulations.

### Step 4: Enrollment Exposure and Risk Quantification
To quantify the exposure spanning 2022 through the end of the 2025 season, multiple enrollment sources were reconciled:
*   *Camper-Days and Tenure Exposure Workbook 2022-2025* (**Camper-Days by Unit** sheet - 48 rows per season):
    *   2022: S1: 235, S2: 217, S3: 212. Total Enrolled: 664. Camper-days: 12,856.
    *   2023: S1: 221, S2: 226, S3: 231. Total Enrolled: 678. Camper-days: 13,098.
    *   2024: S1: 223, S2: 252, S3: 241. Total Enrolled: 716. Camper-days: 13,838.
    *   2025: S1: 215, S2: 240, S3: 224. Total Enrolled: 679. Camper-days: 13,132.
*   *Session Enrollment Summary 2022-2026* (9 rows per season):
    *   2022: S1: 258, S2: 260, S3: 255. Total Enrolled: 773. Camper-days: 14,950.
    *   2023: S1: 261, S2: 262, S3: 266. Total Enrolled: 789. Camper-days: 15,248.
    *   2024: S1: 270, S2: 268, S3: 261. Total Enrolled: 799. Camper-days: 15,458.
    *   2025: S1: 257, S2: 257, S3: 260. Total Enrolled: 774. Camper-days: 14,960.
*   *Camper-Days and Tenure Exposure Workbook 2022-2025* (**Season Summary** sheet): Reported 2022–2025 enrollment totals of 788, 795, 805, and 812, with camper-days matching the *Camper-Days by Unit* sheet (e.g., 12,856 for 2022).
*   *Corrigwell Swim Classification Rosters* (Unique assessments): Valid counts yielded 791, 798, 808, and 815 for 2022–2025 respectively.

**Discrepancy Note & Selected Figures**: The *Camper-Days by Unit* source is the most granular, providing line-by-line unit breakdowns (48 rows vs. 9 rows). Therefore, its figures (Total Enrolled: 664 [2022], 678 [2023], 716 [2024], 679 [2025]; Total Camper-Days: 12,856 [2022], 13,098 [2023], 13,838 [2024], 13,132 [2025]) must be used as the definitive measure of exposure at Corrigwell.

**Insurance Program Schedules Discrepancy**: 
The *Insurance Program Schedule 2024-2025* and *2025-2026* report an exposure basis of "approximately 4,800 campers annually across six sites." However, the *Session Enrollment Summary 2022-2026* shows total annual enrollment across all six sites ranging from 1,840 to 1,901 campers. This reveals a massive discrepancy, with the insurance schedule inflating the figure by approximately 2,900 campers over the underlying records. 

**Open Claims and Loss Experience**:
The provided *Loss Runs* (Abuse and Molestation, General Liability, Workers Compensation) bear a valuation date of July 22, 2026. Because this date is after the July 14 cutoff, these figures are not available from a document that existed as of July 14. Therefore, this data cannot be used, creating an unestimable risk regarding the camp's current loss position and its impact on renewal.

**Timing and Pending Deadlines**:
If nothing is done to correct these findings, the organization risks regulatory penalties, license suspension, and the loss of insurance coverage. As of July 14, 2026:
*   The *Youth Camp License Renewal Application 2026* is due to the state on July 15, 2026 (1 day remaining). 
*   The Corrective Action Plan (CAP) response must be submitted to the Bureau within 45 days of the June 15 letter, making it due by July 30, 2026 (16 days remaining). 
*   The underwriting documentation window for Great Pines Mutual required submission 30 days before the August 1 policy anniversary (July 2, which has already passed).
